# project

打包项目本身，忽略ignore和git文件。可用于分发项目，创建模板。
