# 启动说明

## NodeJS

```bash
node ./dist/server/main.js
```

或：

```bash
sh start.sh
```

## Docker-Compose

```bash
docker-compose up -d
```

## pm2

```bash
pm2 start
```
