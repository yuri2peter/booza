#!/bin/sh

node ./dist/server/main.js