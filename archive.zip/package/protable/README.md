# protable

便携式nodejs应用（自带windows nodejs环境）打包脚本
