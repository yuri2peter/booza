#!/bin/bash

docker run -p 3000:3000 --init --rm --name test-empty-project empty-project:v1
