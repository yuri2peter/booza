#!/bin/bash

npm ci --silent
npm start
