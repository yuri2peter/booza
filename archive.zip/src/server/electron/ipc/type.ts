export type IpcHandles = Record<string, (...args: any[]) => any>;
